﻿namespace osuRefMaui.Core.IRC.LoginInformation;

public class Credentials
{
    public string Username { get; set; }
    public string IrcPassword { get; set; }
    public bool RememberMe { get; set; }
}